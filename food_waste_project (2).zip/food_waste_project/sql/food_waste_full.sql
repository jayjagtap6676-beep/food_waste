-- Food Waste Recovery & Redistribution System | MySQL 8.0.16 or newer (CHECK is enforced from 8.0.16)
DROP DATABASE IF EXISTS food_waste_db;
CREATE DATABASE food_waste_db;
USE food_waste_db;

-- SECTION 1 : TABLES AND CONSTRAINTS (parent tables first)

CREATE TABLE User_Account (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL CHECK (CHAR_LENGTH(password) >= 4),
  role VARCHAR(10) NOT NULL CHECK (role IN ('Admin','Donor','NGO','Volunteer')),
  account_status VARCHAR(10) NOT NULL DEFAULT 'Active' CHECK (account_status IN ('Active','Blocked')),
  created_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_time DATETIME NULL
);

CREATE TABLE Food_Category (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(50) NOT NULL UNIQUE,
  storage_type VARCHAR(10) NOT NULL CHECK (storage_type IN ('Room','Chilled','Frozen','Hot')),
  safe_hours INT NOT NULL CHECK (safe_hours > 0)
);

CREATE TABLE Donor (
  donor_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  donor_name VARCHAR(100) NOT NULL,
  donor_type VARCHAR(15) NOT NULL CHECK (donor_type IN ('Restaurant','Hotel','Caterer','Bakery','Store','Individual')),
  contact_person VARCHAR(60) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE CHECK (email LIKE '%_@_%._%'),
  street VARCHAR(100) NOT NULL,
  city VARCHAR(50) NOT NULL,
  pincode CHAR(6) NOT NULL CHECK (CHAR_LENGTH(pincode) = 6),
  registered_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES User_Account(user_id)
);

CREATE TABLE Donor_Phone (
  donor_id INT NOT NULL,
  phone CHAR(10) NOT NULL CHECK (CHAR_LENGTH(phone) = 10),
  PRIMARY KEY (donor_id, phone),
  FOREIGN KEY (donor_id) REFERENCES Donor(donor_id) ON DELETE CASCADE
);

CREATE TABLE NGO (
  ngo_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  ngo_name VARCHAR(100) NOT NULL,
  registration_no VARCHAR(30) NOT NULL UNIQUE,
  contact_person VARCHAR(60) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE CHECK (email LIKE '%_@_%._%'),
  street VARCHAR(100) NOT NULL,
  city VARCHAR(50) NOT NULL,
  pincode CHAR(6) NOT NULL CHECK (CHAR_LENGTH(pincode) = 6),
  daily_capacity_kg DECIMAL(8,2) NOT NULL CHECK (daily_capacity_kg > 0),
  verified_status VARCHAR(10) NOT NULL DEFAULT 'Pending' CHECK (verified_status IN ('Pending','Verified','Rejected')),
  registered_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES User_Account(user_id)
);

CREATE TABLE NGO_Phone (
  ngo_id INT NOT NULL,
  phone CHAR(10) NOT NULL CHECK (CHAR_LENGTH(phone) = 10),
  PRIMARY KEY (ngo_id, phone),
  FOREIGN KEY (ngo_id) REFERENCES NGO(ngo_id) ON DELETE CASCADE
);

CREATE TABLE Volunteer (
  volunteer_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  volunteer_name VARCHAR(60) NOT NULL,
  phone CHAR(10) NOT NULL CHECK (CHAR_LENGTH(phone) = 10),
  vehicle_type VARCHAR(10) NOT NULL DEFAULT 'None' CHECK (vehicle_type IN ('None','Bicycle','Bike','Car','Truck','Van')),
  availability VARCHAR(10) NOT NULL DEFAULT 'Available' CHECK (availability IN ('Available','Busy','Offline')),
  joined_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES User_Account(user_id)
);

CREATE TABLE Food_Listing (
  listing_id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT NOT NULL,
  category_id INT NOT NULL,
  food_name VARCHAR(100) NOT NULL,
  quantity_kg DECIMAL(8,2) NOT NULL CHECK (quantity_kg >= 0),
  prepared_on DATETIME NOT NULL,
  expiry_on DATETIME NOT NULL,
  pickup_deadline DATETIME NOT NULL,
  listed_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  listing_status VARCHAR(10) NOT NULL DEFAULT 'Available' CHECK (listing_status IN ('Available','Allocated','Expired','Cancelled')),
  FOREIGN KEY (donor_id) REFERENCES Donor(donor_id),
  FOREIGN KEY (category_id) REFERENCES Food_Category(category_id),
  CHECK (expiry_on > prepared_on),
  CHECK (pickup_deadline <= expiry_on)
);

CREATE TABLE Collection_Request (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  listing_id INT NOT NULL,
  ngo_id INT NOT NULL,
  quantity_kg DECIMAL(8,2) NOT NULL CHECK (quantity_kg > 0),
  requested_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  approved_on DATETIME NULL,
  request_status VARCHAR(10) NOT NULL DEFAULT 'Pending' CHECK (request_status IN ('Pending','Approved','Rejected','Cancelled','Completed')),
  FOREIGN KEY (listing_id) REFERENCES Food_Listing(listing_id),
  FOREIGN KEY (ngo_id) REFERENCES NGO(ngo_id)
);

CREATE TABLE Delivery ( -- UNIQUE(request_id) makes the relationship 1 : 0..1
  delivery_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL UNIQUE,
  volunteer_id INT NOT NULL,
  pickup_time DATETIME NULL,
  delivery_time DATETIME NULL,
  delivered_kg DECIMAL(8,2) NULL CHECK (delivered_kg IS NULL OR delivered_kg >= 0),
  delivery_status VARCHAR(10) NOT NULL DEFAULT 'Assigned' CHECK (delivery_status IN ('Assigned','Picked Up','Delivered','Failed')),
  FOREIGN KEY (request_id) REFERENCES Collection_Request(request_id),
  FOREIGN KEY (volunteer_id) REFERENCES Volunteer(volunteer_id),
  CHECK (pickup_time IS NULL OR delivery_time IS NULL OR delivery_time >= pickup_time)
);

CREATE TABLE Quality_Check ( -- weak entity: key = (delivery_id, check_no); check_no and result get a DEFAULT only because trg_quality_bi overwrites them
  delivery_id INT NOT NULL,
  check_no INT NOT NULL DEFAULT 0,
  check_stage VARCHAR(10) NOT NULL CHECK (check_stage IN ('Pickup','Delivery')),
  checked_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  temperature_c DECIMAL(5,2) NULL,
  packaging_ok CHAR(1) NOT NULL CHECK (packaging_ok IN ('Y','N')),
  appearance_ok CHAR(1) NOT NULL CHECK (appearance_ok IN ('Y','N')),
  result VARCHAR(4) NOT NULL DEFAULT 'Pass' CHECK (result IN ('Pass','Fail')),
  remarks VARCHAR(200) NULL,
  PRIMARY KEY (delivery_id, check_no),
  FOREIGN KEY (delivery_id) REFERENCES Delivery(delivery_id) ON DELETE CASCADE,
  UNIQUE (delivery_id, check_stage)
);

SHOW TABLES;

-- SECTION 2 : SAMPLE DATA

INSERT INTO User_Account (username, password, role) VALUES
 ('admin', 'admin123', 'Admin'),
 ('sai_bakery', 'pass123', 'Donor'),
 ('hotel_sunrise', 'pass123', 'Donor'),
 ('freshmart', 'pass123', 'Donor'),
 ('annadaan', 'pass123', 'NGO'),
 ('rotibank', 'pass123', 'NGO'),
 ('asha_home', 'pass123', 'NGO'),
 ('rohan', 'pass123', 'Volunteer'),
 ('meera', 'pass123', 'Volunteer');

INSERT INTO Food_Category (category_name, storage_type, safe_hours) VALUES
 ('Cooked Meals', 'Hot', 4),
 ('Bakery Items', 'Room', 24),
 ('Dairy Products', 'Chilled',12),
 ('Fruits and Vegetables', 'Room', 48),
 ('Frozen Foods', 'Frozen', 72);

INSERT INTO Donor (user_id, donor_name, donor_type, contact_person, email, street, city, pincode) VALUES
 (2, 'Sai Bakery', 'Bakery', 'Suresh Patil', 'sai.bakery@example.com', '12 Link Road', 'Mumbai', '400053'),
 (3, 'Hotel Sunrise', 'Hotel', 'Anita Rao', 'sunrise@example.com', '45 Juhu Tara Road', 'Mumbai', '400049'),
 (4, 'FreshMart', 'Store', 'Imran Shaikh', 'freshmart@example.com', '7 SV Road', 'Mumbai', '400058');

INSERT INTO Donor_Phone (donor_id, phone) VALUES
 (1, '9820011111'), (1, '9820022222'), (2, '9820033333'), (3, '9820044444');

INSERT INTO NGO (user_id, ngo_name, registration_no, contact_person, email, street, city, pincode, daily_capacity_kg, verified_status) VALUES
 (5, 'Annadaan Foundation', 'MH/NGO/2015/101', 'Kavita Joshi', 'annadaan@example.com', '22 Station Road', 'Mumbai', '400057', 200, 'Verified'),
 (6, 'Roti Bank Mumbai', 'MH/NGO/2018/202', 'Farhan Khan', 'rotibank@example.com', '9 Dadar Market', 'Mumbai', '400014', 150, 'Verified'),
 (7, 'Asha Children Home', 'MH/NGO/2022/303', 'Mary Dsouza', 'asha@example.com', '3 Church Lane', 'Mumbai', '400050', 80, 'Pending');

INSERT INTO NGO_Phone (ngo_id, phone) VALUES
 (1, '9930011111'), (2, '9930022222'), (3, '9930033333');

INSERT INTO Volunteer (user_id, volunteer_name, phone, vehicle_type, availability) VALUES
 (8, 'Rohan Mehta', '9870011111', 'Bike', 'Available'),
 (9, 'Meera Nair', '9870022222', 'Car', 'Busy');

INSERT INTO Food_Listing (donor_id, category_id, food_name, quantity_kg, prepared_on, expiry_on, pickup_deadline, listed_on, listing_status) VALUES
 (1, 2, 'Assorted Bread Loaves', 30, DATE_SUB(NOW(), INTERVAL 3 HOUR), DATE_ADD(NOW(), INTERVAL 10 HOUR), DATE_ADD(NOW(), INTERVAL 6 HOUR), DATE_SUB(NOW(), INTERVAL 2 HOUR), 'Available'),
 (2, 1, 'Veg Biryani', 15, DATE_SUB(NOW(), INTERVAL 1 HOUR), DATE_ADD(NOW(), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 1 HOUR), DATE_SUB(NOW(), INTERVAL 30 MINUTE),'Available'),
 (3, 3, 'Packed Milk and Curd', 60, DATE_SUB(NOW(), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 9 HOUR), DATE_ADD(NOW(), INTERVAL 8 HOUR), DATE_SUB(NOW(), INTERVAL 1 HOUR), 'Available'),
 (3, 4, 'Fresh Vegetables', 80, DATE_SUB(NOW(), INTERVAL 5 HOUR), DATE_ADD(NOW(), INTERVAL 40 HOUR), DATE_ADD(NOW(), INTERVAL 30 HOUR), DATE_SUB(NOW(), INTERVAL 4 HOUR), 'Available'),
 (1, 2, 'Pav Buns (old batch)', 10, DATE_SUB(NOW(), INTERVAL 26 HOUR), DATE_SUB(NOW(), INTERVAL 3 HOUR), DATE_SUB(NOW(), INTERVAL 5 HOUR), DATE_SUB(NOW(), INTERVAL 25 HOUR), 'Available');

INSERT INTO Collection_Request (listing_id, ngo_id, quantity_kg, requested_on, approved_on, request_status) VALUES
 (1, 1, 20, DATE_SUB(NOW(), INTERVAL 110 MINUTE), DATE_SUB(NOW(), INTERVAL 100 MINUTE), 'Completed'),
 (2, 2, 25, DATE_SUB(NOW(), INTERVAL 40 MINUTE), DATE_SUB(NOW(), INTERVAL 30 MINUTE), 'Approved'),
 (3, 1, 20, DATE_SUB(NOW(), INTERVAL 20 MINUTE), NULL, 'Pending'),
 (3, 2, 25, DATE_SUB(NOW(), INTERVAL 15 MINUTE), NULL, 'Pending'),
 (5, 1, 5, DATE_SUB(NOW(), INTERVAL 24 HOUR), NULL, 'Pending');

INSERT INTO Delivery (request_id, volunteer_id, pickup_time, delivery_time, delivered_kg, delivery_status) VALUES
 (1, 1, DATE_SUB(NOW(), INTERVAL 90 MINUTE), DATE_SUB(NOW(), INTERVAL 60 MINUTE), 20, 'Delivered'),
 (2, 2, DATE_SUB(NOW(), INTERVAL 10 MINUTE), NULL, NULL, 'Picked Up');

INSERT INTO Quality_Check (delivery_id, check_no, check_stage, temperature_c, packaging_ok, appearance_ok, result, remarks) VALUES
 (1, 1, 'Pickup', NULL, 'Y', 'Y', 'Pass', 'Fresh and well packed'),
 (1, 2, 'Delivery', NULL, 'Y', 'Y', 'Pass', 'Handed over to NGO'),
 (2, 1, 'Pickup', 68.0, 'Y', 'Y', 'Pass', 'Served hot');

-- SECTION 3 : VIEWS

-- food an NGO can still request
CREATE VIEW v_available_listings AS
SELECT l.listing_id, l.food_name, c.category_name, c.storage_type,
 d.donor_name, d.city AS donor_city, l.quantity_kg, l.expiry_on, l.pickup_deadline
FROM Food_Listing l
JOIN Donor d ON d.donor_id = l.donor_id
JOIN Food_Category c ON c.category_id = l.category_id
WHERE l.listing_status = 'Available' AND l.expiry_on > NOW() AND l.quantity_kg > 0;

-- requests waiting for the admin
CREATE VIEW v_pending_requests AS
SELECT r.request_id, n.ngo_name, n.verified_status, l.food_name, d.donor_name,
 r.quantity_kg AS requested_kg, l.quantity_kg AS available_kg, r.requested_on, l.expiry_on
FROM Collection_Request r
JOIN NGO n ON n.ngo_id = r.ngo_id
JOIN Food_Listing l ON l.listing_id = r.listing_id
JOIN Donor d ON d.donor_id = l.donor_id
WHERE r.request_status = 'Pending';

-- full picture of every delivery
CREATE VIEW v_delivery_status AS
SELECT dl.delivery_id, dl.delivery_status, dl.pickup_time, dl.delivery_time, dl.delivered_kg,
 r.quantity_kg AS requested_kg, l.food_name, d.donor_name, d.city AS donor_city,
 n.ngo_name, n.city AS ngo_city, v.volunteer_id, v.volunteer_name
FROM Delivery dl
JOIN Collection_Request r ON r.request_id = dl.request_id
JOIN Food_Listing l ON l.listing_id = r.listing_id
JOIN Donor d ON d.donor_id = l.donor_id
JOIN NGO n ON n.ngo_id = r.ngo_id
JOIN Volunteer v ON v.volunteer_id = dl.volunteer_id;

-- one row per donor, even donors with no listing
CREATE VIEW v_donor_summary AS
SELECT d.donor_id, d.donor_name, d.donor_type,
 COUNT(l.listing_id) AS total_listings,
 COALESCE(SUM(l.quantity_kg), 0) AS stock_left_kg
FROM Donor d
LEFT JOIN Food_Listing l ON l.donor_id = d.donor_id
GROUP BY d.donor_id, d.donor_name, d.donor_type;

-- one row per NGO, with the kilograms it actually received
CREATE VIEW v_ngo_summary AS
SELECT n.ngo_id, n.ngo_name, n.verified_status,
 COUNT(DISTINCT r.request_id) AS requests_made,
 COALESCE(SUM(dl.delivered_kg), 0) AS kg_received
FROM NGO n
LEFT JOIN Collection_Request r ON r.ngo_id = n.ngo_id
LEFT JOIN Delivery dl ON dl.request_id = r.request_id AND dl.delivery_status = 'Delivered'
GROUP BY n.ngo_id, n.ngo_name, n.verified_status;

-- deliveries completed by each volunteer
CREATE VIEW v_volunteer_summary AS
SELECT v.volunteer_id, v.volunteer_name, COUNT(dl.delivery_id) AS deliveries_done
FROM Volunteer v
LEFT JOIN Delivery dl ON dl.volunteer_id = v.volunteer_id AND dl.delivery_status = 'Delivered'
GROUP BY v.volunteer_id, v.volunteer_name;

-- a true comparison counts as 1 and a false one as 0, so SUM counts the matches
CREATE VIEW v_quality_by_category AS
SELECT c.category_name,
 COUNT(q.check_no) AS checks_done,
 SUM(q.result = 'Pass') AS passed,
 SUM(q.result = 'Fail') AS failed
FROM Quality_Check q
JOIN Delivery dl ON dl.delivery_id = q.delivery_id
JOIN Collection_Request r ON r.request_id = dl.request_id
JOIN Food_Listing l ON l.listing_id = r.listing_id
JOIN Food_Category c ON c.category_id = l.category_id
GROUP BY c.category_id, c.category_name;

-- SECTION 4 : TRIGGERS (BEFORE triggers adjust the incoming row NEW; AFTER triggers update other tables)
DELIMITER $$

-- expiry is capped at prepared time + safe hours; food already expired is stored as Expired
CREATE TRIGGER trg_listing_bi
BEFORE INSERT ON Food_Listing
FOR EACH ROW
BEGIN
  DECLARE v_hours INT;
  SELECT safe_hours INTO v_hours FROM Food_Category WHERE category_id = NEW.category_id;

  IF v_hours IS NOT NULL THEN
    SET NEW.expiry_on = LEAST(NEW.expiry_on, DATE_ADD(NEW.prepared_on, INTERVAL v_hours HOUR));
  END IF;
  SET NEW.pickup_deadline = LEAST(NEW.pickup_deadline, NEW.expiry_on);

  IF NEW.expiry_on <= NOW() THEN
    SET NEW.listing_status = 'Expired';
  END IF;
END$$

-- a request is stored as Rejected if the NGO is not verified, the food is expired or unavailable, or the quantity exceeds the stock
CREATE TRIGGER trg_request_bi
BEFORE INSERT ON Collection_Request
FOR EACH ROW
BEGIN
  DECLARE v_verified VARCHAR(10);
  DECLARE v_status VARCHAR(10);
  DECLARE v_expiry DATETIME;
  DECLARE v_stock DECIMAL(8,2);

  SELECT verified_status INTO v_verified FROM NGO WHERE ngo_id = NEW.ngo_id;
  SELECT listing_status, expiry_on, quantity_kg INTO v_status, v_expiry, v_stock
  FROM Food_Listing WHERE listing_id = NEW.listing_id;

  SET NEW.request_status = 'Pending';
  SET NEW.approved_on = NULL;

  IF v_verified IS NULL OR v_verified <> 'Verified'
     OR v_status <> 'Available' OR v_expiry <= NOW()
     OR NEW.quantity_kg > v_stock THEN
    SET NEW.request_status = 'Rejected';
  END IF;
END$$

-- on approval the checks run again (expiry, stock, NGO daily capacity); a finished request keeps its status
CREATE TRIGGER trg_request_bu
BEFORE UPDATE ON Collection_Request
FOR EACH ROW
BEGIN
  DECLARE v_expiry DATETIME;
  DECLARE v_stock DECIMAL(8,2);
  DECLARE v_cap DECIMAL(8,2);
  DECLARE v_used DECIMAL(8,2);

  IF OLD.request_status IN ('Rejected','Cancelled','Completed') THEN
    SET NEW.request_status = OLD.request_status;

  ELSEIF OLD.request_status = 'Pending' AND NEW.request_status = 'Approved' THEN
    SELECT expiry_on, quantity_kg INTO v_expiry, v_stock
    FROM Food_Listing WHERE listing_id = NEW.listing_id;
    SELECT daily_capacity_kg INTO v_cap FROM NGO WHERE ngo_id = NEW.ngo_id;
    SELECT COALESCE(SUM(quantity_kg), 0) INTO v_used FROM Collection_Request
    WHERE ngo_id = NEW.ngo_id AND request_status IN ('Approved','Completed')
      AND approved_on >= DATE_SUB(NOW(), INTERVAL 24 HOUR);

    IF v_expiry <= NOW() OR NEW.quantity_kg > v_stock OR v_used + NEW.quantity_kg > v_cap THEN
      SET NEW.request_status = 'Rejected';
    ELSE
      SET NEW.approved_on = NOW();
    END IF;
  END IF;
END$$

-- stock is deducted on approval and returned if an approved request is cancelled
CREATE TRIGGER trg_request_au
AFTER UPDATE ON Collection_Request
FOR EACH ROW
BEGIN
  IF OLD.request_status = 'Pending' AND NEW.request_status = 'Approved' THEN
    UPDATE Food_Listing SET quantity_kg = quantity_kg - NEW.quantity_kg
    WHERE listing_id = NEW.listing_id;
    UPDATE Food_Listing SET listing_status = 'Allocated'
    WHERE listing_id = NEW.listing_id AND quantity_kg = 0;

  ELSEIF OLD.request_status = 'Approved' AND NEW.request_status = 'Cancelled' THEN
    UPDATE Food_Listing SET quantity_kg = quantity_kg + NEW.quantity_kg
    WHERE listing_id = NEW.listing_id;
    UPDATE Food_Listing SET listing_status = 'Available'
    WHERE listing_id = NEW.listing_id AND listing_status = 'Allocated' AND expiry_on > NOW();
  END IF;
END$$

-- a delivery needs an approved request and a free volunteer; otherwise volunteer_id is set to NULL and MySQL refuses the row (NOT NULL)
CREATE TRIGGER trg_delivery_bi
BEFORE INSERT ON Delivery
FOR EACH ROW
BEGIN
  DECLARE v_req_status VARCHAR(10);
  DECLARE v_avail VARCHAR(10);

  SELECT request_status INTO v_req_status FROM Collection_Request WHERE request_id = NEW.request_id;
  SELECT availability INTO v_avail FROM Volunteer WHERE volunteer_id = NEW.volunteer_id;

  IF v_req_status IS NULL OR v_req_status <> 'Approved' OR v_avail IS NULL OR v_avail <> 'Available' THEN
    SET NEW.volunteer_id = NULL;
  END IF;
  SET NEW.delivery_status = 'Assigned';
END$$

-- the volunteer becomes Busy as soon as a delivery is assigned
CREATE TRIGGER trg_delivery_ai
AFTER INSERT ON Delivery
FOR EACH ROW
BEGIN
  UPDATE Volunteer SET availability = 'Busy' WHERE volunteer_id = NEW.volunteer_id;
END$$

-- when a delivery ends the volunteer is free again; Delivered completes the request, Failed cancels it (stock returns via trg_request_au)
CREATE TRIGGER trg_delivery_au
AFTER UPDATE ON Delivery
FOR EACH ROW
BEGIN
  IF OLD.delivery_status <> NEW.delivery_status THEN
    IF NEW.delivery_status = 'Delivered' THEN
      UPDATE Volunteer SET availability = 'Available' WHERE volunteer_id = NEW.volunteer_id;
      UPDATE Collection_Request SET request_status = 'Completed' WHERE request_id = NEW.request_id;
    ELSEIF NEW.delivery_status = 'Failed' THEN
      UPDATE Volunteer SET availability = 'Available' WHERE volunteer_id = NEW.volunteer_id;
      UPDATE Collection_Request SET request_status = 'Cancelled'
      WHERE request_id = NEW.request_id AND request_status = 'Approved';
    END IF;
  END IF;
END$$

-- check_no is numbered automatically; the result is Fail for bad packaging or looks, chilled above 8 C, frozen above -15 C, hot below 60 C
CREATE TRIGGER trg_quality_bi
BEFORE INSERT ON Quality_Check
FOR EACH ROW
BEGIN
  DECLARE v_next INT;
  DECLARE v_storage VARCHAR(10);

  SELECT COALESCE(MAX(check_no), 0) + 1 INTO v_next
  FROM Quality_Check WHERE delivery_id = NEW.delivery_id;
  SET NEW.check_no = v_next;

  SELECT c.storage_type INTO v_storage
  FROM Delivery dl
  JOIN Collection_Request r ON r.request_id = dl.request_id
  JOIN Food_Listing l ON l.listing_id = r.listing_id
  JOIN Food_Category c ON c.category_id = l.category_id
  WHERE dl.delivery_id = NEW.delivery_id;

  SET NEW.result = 'Pass';
  IF NEW.packaging_ok = 'N' OR NEW.appearance_ok = 'N' THEN
    SET NEW.result = 'Fail';
  ELSEIF v_storage = 'Chilled' AND NEW.temperature_c > 8 THEN
    SET NEW.result = 'Fail';
  ELSEIF v_storage = 'Frozen' AND NEW.temperature_c > -15 THEN
    SET NEW.result = 'Fail';
  ELSEIF v_storage = 'Hot' AND NEW.temperature_c < 60 THEN
    SET NEW.result = 'Fail';
  END IF;
END$$

-- a failed quality check fails the delivery (trg_delivery_au does the rest)
CREATE TRIGGER trg_quality_ai
AFTER INSERT ON Quality_Check
FOR EACH ROW
BEGIN
  IF NEW.result = 'Fail' THEN
    UPDATE Delivery SET delivery_status = 'Failed'
    WHERE delivery_id = NEW.delivery_id AND delivery_status IN ('Assigned','Picked Up');
  END IF;
END$$

DELIMITER ;

-- SECTION 5 : EXPIRY CLEAN-UP

UPDATE Collection_Request SET request_status = 'Rejected' -- pending requests on expired food are rejected first
WHERE request_status = 'Pending'
  AND listing_id IN (SELECT listing_id FROM Food_Listing WHERE expiry_on <= NOW());

UPDATE Food_Listing SET listing_status = 'Expired'
WHERE listing_status = 'Available' AND expiry_on <= NOW();

-- SECTION 6 : TRANSACTIONS

-- 6.1 approve a request and assign a volunteer
START TRANSACTION;
UPDATE Collection_Request SET request_status = 'Approved' WHERE request_id = 3;
INSERT INTO Delivery (request_id, volunteer_id) VALUES (3, 1);
SELECT request_id, request_status FROM Collection_Request WHERE request_id = 3;
COMMIT;

-- 6.2 register a donor with phone numbers (if a phone is invalid, ROLLBACK TO SAVEPOINT donor_saved keeps the donor so only the phones are retried)
START TRANSACTION;
INSERT INTO User_Account (username, password, role) VALUES ('green_kitchen', 'pass123', 'Donor');
INSERT INTO Donor (user_id, donor_name, donor_type, contact_person, email, street, city, pincode)
 VALUES ((SELECT user_id FROM User_Account WHERE username = 'green_kitchen'),
 'Green Kitchen', 'Restaurant', 'Neha Shah', 'greenkitchen@example.com', '8 Hill Road', 'Mumbai', '400050');
SAVEPOINT donor_saved;
INSERT INTO Donor_Phone (donor_id, phone) VALUES
 ((SELECT donor_id FROM Donor WHERE donor_name = 'Green Kitchen'), '9810011111'),
 ((SELECT donor_id FROM Donor WHERE donor_name = 'Green Kitchen'), '9810022222');
COMMIT;

-- 6.3 finish a delivery: the quality check and the status change are saved together (if the check result is Fail, run ROLLBACK instead)
START TRANSACTION;
INSERT INTO Quality_Check (delivery_id, check_stage, temperature_c, packaging_ok, appearance_ok, remarks)
 VALUES (2, 'Delivery', 65.0, 'Y', 'Y', 'Received by NGO');
SELECT delivery_id, check_no, result FROM Quality_Check WHERE delivery_id = 2;
UPDATE Delivery SET delivery_status = 'Delivered', delivery_time = NOW(), delivered_kg = 25 WHERE delivery_id = 2;
COMMIT;
