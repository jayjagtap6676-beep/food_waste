# app.py | run:  python app.py   ->  http://localhost:5000
import mysql.connector
from flask import Flask, render_template, request, redirect, url_for, session, flash
from db import query, execute, get_conn, db_message
from auth import login_required
from listings import listings_bp      # Sharvari
from delivery import delivery_bp      # Aksh

app = Flask(__name__)
app.secret_key = "dbms-mini-project-secret"
app.register_blueprint(listings_bp)
app.register_blueprint(delivery_bp)


@app.route("/")
def home():
    return redirect(url_for("dashboard") if "user_id" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = query("""SELECT u.user_id, u.username, u.role, u.account_status,
                            COALESCE(d.donor_id, n.ngo_id, v.volunteer_id) AS profile_id,
                            COALESCE(d.donor_name, n.ngo_name, v.volunteer_name, 'Administrator') AS display_name
                     FROM User_Account u
                     LEFT JOIN Donor d     ON d.user_id = u.user_id
                     LEFT JOIN NGO n       ON n.user_id = u.user_id
                     LEFT JOIN Volunteer v ON v.user_id = u.user_id
                     WHERE u.username = %s AND u.password = %s""",
                  (request.form["username"], request.form["password"]), one=True)
        if u is None:
            flash("Invalid username or password", "danger")
            return render_template("login.html")
        if u["account_status"] != "Active":
            flash("This account is blocked", "danger")
            return render_template("login.html")
        execute("UPDATE User_Account SET last_login_time = NOW() WHERE user_id = %s", (u["user_id"],))
        session.clear()
        session.update(user_id=u["user_id"], username=u["username"], role=u["role"],
                       pid=u["profile_id"], name=u["display_name"])
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/register/<role>", methods=["GET", "POST"])
def register(role):
    if role not in ("Donor", "NGO", "Volunteer"):
        return redirect(url_for("login"))
    if request.method == "POST":
        f = request.form
        phones = [p.strip() for p in f.get("phones", "").split(",") if p.strip()]
        if role != "Volunteer" and not phones:
            flash("Enter at least one phone number.", "danger")
            return render_template("register.html", role=role, f=f)
        conn = get_conn()
        try:
            cur = conn.cursor()
            conn.start_transaction()                      # user + profile + phones: all or nothing
            cur.execute("INSERT INTO User_Account (username, password, role) VALUES (%s,%s,%s)",
                        (f["username"], f["password"], role))
            uid = cur.lastrowid
            if role == "Donor":
                cur.execute("""INSERT INTO Donor (user_id, donor_name, donor_type, contact_person, email, street, city, pincode)
                               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                            (uid, f["name"], f["donor_type"], f["contact"], f["email"], f["street"], f["city"], f["pincode"]))
                pid = cur.lastrowid
                for p in phones:
                    cur.execute("INSERT INTO Donor_Phone (donor_id, phone) VALUES (%s,%s)", (pid, p))
            elif role == "NGO":
                cur.execute("""INSERT INTO NGO (user_id, ngo_name, registration_no, contact_person, email, street, city, pincode, daily_capacity_kg)
                               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                            (uid, f["name"], f["registration_no"], f["contact"], f["email"], f["street"], f["city"], f["pincode"], f["capacity"]))
                pid = cur.lastrowid
                for p in phones:
                    cur.execute("INSERT INTO NGO_Phone (ngo_id, phone) VALUES (%s,%s)", (pid, p))
            else:
                cur.execute("INSERT INTO Volunteer (user_id, volunteer_name, phone, vehicle_type) VALUES (%s,%s,%s,%s)",
                            (uid, f["name"], f["phone"], f["vehicle_type"]))
            conn.commit()
            flash("Registered! " + ("An admin must verify your NGO before you can request food. " if role == "NGO" else "") + "Please log in.", "success")
            return redirect(url_for("login"))
        except mysql.connector.Error as e:
            conn.rollback()
            flash(db_message(e), "danger")
        finally:
            conn.close()
        return render_template("register.html", role=role, f=f)
    return render_template("register.html", role=role, f={})


DELIVERED = """SELECT COALESCE(SUM(dl.delivered_kg),0) AS c FROM Delivery dl
               JOIN Collection_Request r ON r.request_id = dl.request_id
               JOIN Food_Listing f ON f.listing_id = r.listing_id
               WHERE dl.delivery_status = 'Delivered' AND """
STATS = {
    "Admin": [("NGOs awaiting verification", "SELECT COUNT(*) AS c FROM NGO WHERE verified_status='Pending'"),
              ("Pending requests", "SELECT COUNT(*) AS c FROM Collection_Request WHERE request_status='Pending'"),
              ("Approved, no volunteer yet", """SELECT COUNT(*) AS c FROM Collection_Request r LEFT JOIN Delivery d ON d.request_id=r.request_id
                                                WHERE r.request_status='Approved' AND d.delivery_id IS NULL"""),
              ("Active deliveries", "SELECT COUNT(*) AS c FROM Delivery WHERE delivery_status IN ('Assigned','Picked Up')")],
    "Donor": [("My available listings", "SELECT COUNT(*) AS c FROM Food_Listing WHERE donor_id=%s AND listing_status='Available'"),
              ("Kg delivered from my food", DELIVERED + "f.donor_id=%s")],
    "NGO": [("My pending requests", "SELECT COUNT(*) AS c FROM Collection_Request WHERE ngo_id=%s AND request_status='Pending'"),
            ("Kg received", DELIVERED + "r.ngo_id=%s")],
    "Volunteer": [("My active deliveries", "SELECT COUNT(*) AS c FROM Delivery WHERE volunteer_id=%s AND delivery_status IN ('Assigned','Picked Up')"),
                  ("Deliveries completed", "SELECT COUNT(*) AS c FROM Delivery WHERE volunteer_id=%s AND delivery_status='Delivered'")],
}


@app.route("/dashboard")
@login_required()
def dashboard():
    params = () if session["role"] == "Admin" else (session["pid"],)
    stats = [(label, query(sql, params, one=True)["c"]) for label, sql in STATS[session["role"]]]
    return render_template("dashboard.html", stats=stats)


@app.route("/admin/ngos")
@login_required("Admin")
def admin_ngos():
    ngos = query("""SELECT ngo_id, ngo_name, registration_no, city, daily_capacity_kg, verified_status, registered_on
                    FROM NGO ORDER BY verified_status, registered_on""")
    return render_template("admin_ngos.html", ngos=ngos)


@app.route("/admin/ngos/<int:ngo_id>/<action>", methods=["POST"])
@login_required("Admin")
def set_ngo_status(ngo_id, action):
    status = {"verify": "Verified", "reject": "Rejected"}.get(action)
    if status:
        execute("UPDATE NGO SET verified_status=%s WHERE ngo_id=%s", (status, ngo_id))
        flash(f"NGO marked {status}.", "success")
    return redirect(url_for("admin_ngos"))


if __name__ == "__main__":
    app.run(debug=True)
