# db.py | all MySQL access goes through these helpers
import mysql.connector

try:
    from config_local import DB_PASSWORD      # each member creates their OWN config_local.py (never shared)
except ImportError:
    DB_PASSWORD = "root"

DB_CONFIG = {"host": "localhost", "user": "root", "password": DB_PASSWORD, "database": "food_waste_db"}


def get_conn():
    return mysql.connector.connect(**DB_CONFIG)


def query(sql, params=(), one=False):
    """SELECT -> list of dicts (or one dict / None when one=True)."""
    conn = get_conn()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params)
        rows = cur.fetchall()
        if one:
            return rows[0] if rows else None
        return rows
    finally:
        conn.close()


def execute(sql, params=()):
    """INSERT/UPDATE/DELETE -> commits, returns lastrowid. Trigger errors raise mysql.connector.Error."""
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def run_in_transaction(steps):
    """Runs several statements as ONE transaction: COMMIT if all succeed, ROLLBACK if any fails.
    steps = [(sql, params), ...]; returns the number of rows each statement changed."""
    conn = get_conn()
    try:
        cur = conn.cursor()
        conn.start_transaction()
        counts = []
        for sql, params in steps:
            cur.execute(sql, params)
            counts.append(cur.rowcount)
        conn.commit()
        return counts
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def expire_listings():
    """The expiry clean-up of the SQL file (section 5): pending requests on expired food are rejected, then the listings are marked Expired."""
    run_in_transaction([
        ("""UPDATE Collection_Request SET request_status = 'Rejected'
            WHERE request_status = 'Pending'
              AND listing_id IN (SELECT listing_id FROM Food_Listing WHERE expiry_on <= NOW())""", ()),
        ("UPDATE Food_Listing SET listing_status = 'Expired' WHERE listing_status = 'Available' AND expiry_on <= NOW()", ()),
    ])

def db_message(err):
    """Readable text of a MySQL error (a CHECK / FOREIGN KEY / NOT NULL message)."""
    return getattr(err, "msg", None) or str(err)
