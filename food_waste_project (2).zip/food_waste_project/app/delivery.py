# delivery.py | assigning volunteers, delivery life cycle, quality checks, reports
import mysql.connector
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from auth import login_required
from db import query, execute, run_in_transaction, db_message

delivery_bp = Blueprint("delivery", __name__)


# ---------------- ADMIN: assign volunteers ----------------
@delivery_bp.route("/admin/assign")
@login_required("Admin")
def assign():
    reqs = query("""SELECT r.request_id, r.quantity_kg, f.food_name, d.donor_name, d.street AS donor_street,
                           d.city AS donor_city, n.ngo_name, n.city AS ngo_city
                    FROM Collection_Request r
                    JOIN Food_Listing f ON f.listing_id = r.listing_id
                    JOIN Donor d ON d.donor_id = f.donor_id
                    JOIN NGO n ON n.ngo_id = r.ngo_id
                    LEFT JOIN Delivery dl ON dl.request_id = r.request_id
                    WHERE r.request_status = 'Approved' AND dl.delivery_id IS NULL
                    ORDER BY r.approved_on""")
    vols = query("SELECT volunteer_id, volunteer_name, vehicle_type FROM Volunteer WHERE availability='Available'")
    return render_template("assign.html", reqs=reqs, vols=vols)


@delivery_bp.route("/admin/assign", methods=["POST"])
@login_required("Admin")
def do_assign():
    try:
        execute("INSERT INTO Delivery (request_id, volunteer_id) VALUES (%s,%s)",
                (request.form["request_id"], request.form["volunteer_id"]))
        flash("Volunteer assigned.", "success")
    except mysql.connector.Error as e:
        if e.errno == 1048:      # the delivery trigger refused the row
            flash("Could not assign: the request must be Approved and the volunteer must be Available.", "danger")
        else:
            flash(db_message(e), "danger")
    return redirect(url_for("delivery.assign"))

# ---------------- VOLUNTEER ----------------
@delivery_bp.route("/volunteer/deliveries")
@login_required("Volunteer")
def my_deliveries():
    rows = query("SELECT * FROM v_delivery_status WHERE volunteer_id=%s ORDER BY delivery_id DESC", (session["pid"],))
    checks = {}
    for q in query("""SELECT q.* FROM Quality_Check q JOIN Delivery d ON d.delivery_id = q.delivery_id
                      WHERE d.volunteer_id=%s ORDER BY q.delivery_id, q.check_no""", (session["pid"],)):
        checks.setdefault(q["delivery_id"], []).append(q)
    return render_template("my_deliveries.html", rows=rows, checks=checks)


# status order: Assigned > Picked Up > Delivered (Failed is possible before delivery); Picked Up / Delivered need a passing quality check
PREVIOUS = {"Picked Up": ("Assigned",), "Delivered": ("Picked Up",), "Failed": ("Assigned", "Picked Up")}
STAGE = {"Picked Up": "Pickup", "Delivered": "Delivery"}

@delivery_bp.route("/volunteer/deliveries/<int:delivery_id>/status", methods=["POST"])
@login_required("Volunteer")
def set_status(delivery_id):
    status = request.form["status"]
    mine = query("""SELECT r.quantity_kg FROM Delivery d JOIN Collection_Request r ON r.request_id = d.request_id
                    WHERE d.delivery_id=%s AND d.volunteer_id=%s""", (delivery_id, session["pid"]), one=True)
    if status not in PREVIOUS or mine is None:
        flash("That is not your delivery.", "danger")
        return redirect(url_for("delivery.my_deliveries"))
    sql = "UPDATE Delivery SET delivery_status=%s"
    params = [status]
    if status == "Picked Up":
        sql += ", pickup_time = NOW()"
    if status == "Delivered":
        sql += ", delivery_time = NOW(), delivered_kg = %s"
        params.append(request.form.get("delivered_kg") or mine["quantity_kg"])
    sql += " WHERE delivery_id=%s AND volunteer_id=%s AND delivery_status IN (" + ",".join(["%s"] * len(PREVIOUS[status])) + ")"
    params += [delivery_id, session["pid"]] + list(PREVIOUS[status])
    if status in STAGE:
        sql += """ AND EXISTS (SELECT 1 FROM Quality_Check q WHERE q.delivery_id = Delivery.delivery_id
                               AND q.check_stage = %s AND q.result = 'Pass')"""
        params.append(STAGE[status])
    try:
        changed = run_in_transaction([(sql, tuple(params))])[0]
        if changed:
            flash("Status updated.", "success")
        else:
            flash("Not allowed yet: save a passing " + STAGE.get(status, "") + " quality check first and keep the order Assigned > Picked Up > Delivered.", "danger")
    except mysql.connector.Error as e:
        flash(db_message(e), "danger")
    return redirect(url_for("delivery.my_deliveries"))

@delivery_bp.route("/volunteer/deliveries/<int:delivery_id>/quality", methods=["POST"])
@login_required("Volunteer")
def add_quality(delivery_id):
    f = request.form
    if not query("SELECT 1 AS x FROM Delivery WHERE delivery_id=%s AND volunteer_id=%s", (delivery_id, session["pid"]), one=True):
        flash("That is not your delivery.", "danger")
        return redirect(url_for("delivery.my_deliveries"))
    try:
        execute("""INSERT INTO Quality_Check (delivery_id, check_stage, temperature_c, packaging_ok, appearance_ok, remarks)
                   VALUES (%s,%s,%s,%s,%s,%s)""",
                (delivery_id, f["check_stage"], f["temperature_c"],
                 "Y" if f.get("packaging_ok") else "N", "Y" if f.get("appearance_ok") else "N", f.get("remarks", "")))
        result = query("SELECT result FROM Quality_Check WHERE delivery_id=%s AND check_stage=%s", (delivery_id, f["check_stage"]), one=True)
        if result and result["result"] == "Fail":      # the triggers have already failed the delivery, cancelled the request and returned the stock
            flash("Quality check FAILED: the delivery was marked Failed, the request was cancelled and the food went back to stock.", "warning")
        else:
            flash("Quality check recorded (result is calculated by the database).", "success")
    except mysql.connector.Error as e:
        flash(db_message(e), "danger")
    return redirect(url_for("delivery.my_deliveries"))


# ---------------- ADMIN: reports (all from views) ----------------
@delivery_bp.route("/admin/reports")
@login_required("Admin")
def reports():
    reports = {
        "Donor summary": query("SELECT * FROM v_donor_summary"),
        "NGO summary": query("SELECT * FROM v_ngo_summary"),
        "All deliveries": query("""SELECT delivery_id, food_name, donor_name, ngo_name, volunteer_name,
                                          delivery_status, delivered_kg FROM v_delivery_status ORDER BY delivery_id DESC"""),
        "Quality checks by category and result": query("SELECT * FROM v_quality_by_category ORDER BY category_name"),
        "Volunteer leaderboard": query("SELECT volunteer_name, deliveries_done FROM v_volunteer_summary ORDER BY deliveries_done DESC"),
    }
    return render_template("reports.html", reports=reports)
