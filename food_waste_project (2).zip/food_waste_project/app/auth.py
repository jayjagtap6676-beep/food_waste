# auth.py | role-based access: @login_required("Admin") etc.
from functools import wraps
from flask import session, redirect, url_for, flash


def login_required(*roles):
    def deco(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in first.", "warning")
                return redirect(url_for("login"))
            if roles and session.get("role") not in roles:
                flash("You are not allowed to open that page.", "danger")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return deco
