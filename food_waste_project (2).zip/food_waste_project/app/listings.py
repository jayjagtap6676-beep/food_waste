# listings.py | donor listings, NGO browsing/requests, admin approval
from datetime import datetime
import mysql.connector
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from auth import login_required
from db import query, execute, run_in_transaction, expire_listings, db_message

listings_bp = Blueprint("listings", __name__)


def dt(value):                                   # '2026-10-17T14:30' -> '2026-10-17 14:30'
    return value.replace("T", " ")


# ---------------- DONOR ----------------
@listings_bp.route("/donor/listings")
@login_required("Donor")
def donor_listings():
    expire_listings()
    rows = query("""SELECT f.*, c.category_name FROM Food_Listing f
                    JOIN Food_Category c ON c.category_id = f.category_id
                    WHERE f.donor_id = %s ORDER BY f.listed_on DESC""", (session["pid"],))
    cats = query("SELECT category_id, category_name, storage_type, safe_hours FROM Food_Category ORDER BY category_name")
    return render_template("donor_listings.html", rows=rows, cats=cats,
                           now=datetime.now().strftime("%Y-%m-%dT%H:%M"))


@listings_bp.route("/donor/listings/add", methods=["POST"])
@login_required("Donor")
def add_listing():
    f = request.form
    try:
        new_id = execute("""INSERT INTO Food_Listing (donor_id, category_id, food_name, quantity_kg, prepared_on, expiry_on, pickup_deadline)
                            VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                         (session["pid"], f["category_id"], f["food_name"], f["quantity_kg"],
                          dt(f["prepared_on"]), dt(f["expiry_on"]), dt(f["pickup_deadline"])))
        saved = query("SELECT listing_status, expiry_on FROM Food_Listing WHERE listing_id = %s", (new_id,), one=True)
        asked = datetime.strptime(dt(f["expiry_on"]), "%Y-%m-%d %H:%M")
        if saved["listing_status"] == "Expired":
            flash("That food is already expired, so it was saved with status Expired.", "warning")
        elif saved["expiry_on"] != asked:
            flash("Listing posted, but the expiry was shortened to " + str(saved["expiry_on"]) +
                  " because this category is only safe for a limited number of hours.", "warning")
        else:
            flash("Listing posted.", "success")
    except mysql.connector.Error as e:
        flash(db_message(e), "danger")
    return redirect(url_for("listings.donor_listings"))

@listings_bp.route("/donor/listings/<int:listing_id>/cancel", methods=["POST"])
@login_required("Donor")
def cancel_listing(listing_id):
    try:
        counts = run_in_transaction([      # one transaction: both statements are saved together or not at all
            ("""UPDATE Collection_Request SET request_status = 'Rejected'
                WHERE request_status = 'Pending'
                  AND listing_id IN (SELECT listing_id FROM Food_Listing
                                     WHERE listing_id = %s AND donor_id = %s AND listing_status = 'Available')""",
             (listing_id, session["pid"])),
            ("UPDATE Food_Listing SET listing_status = 'Cancelled' WHERE listing_id = %s AND donor_id = %s AND listing_status = 'Available'",
             (listing_id, session["pid"])),
        ])
        if counts[1]:
            flash("Listing cancelled.", "success")
        else:
            flash("Only your own available listings can be cancelled.", "danger")
    except mysql.connector.Error as e:
        flash(db_message(e), "danger")
    return redirect(url_for("listings.donor_listings"))

# ---------------- NGO ----------------
@listings_bp.route("/ngo/browse")
@login_required("NGO")
def browse():
    expire_listings()
    rows = query("SELECT * FROM v_available_listings ORDER BY expiry_on")
    ngo = query("SELECT verified_status FROM NGO WHERE ngo_id=%s", (session["pid"],), one=True)
    return render_template("browse.html", rows=rows, status=ngo["verified_status"])


@listings_bp.route("/ngo/request", methods=["POST"])
@login_required("NGO")
def place_request():
    try:
        rid = execute("INSERT INTO Collection_Request (listing_id, ngo_id, quantity_kg) VALUES (%s,%s,%s)",
                      (request.form["listing_id"], session["pid"], request.form["quantity_kg"]))
        saved = query("SELECT request_status FROM Collection_Request WHERE request_id = %s", (rid,), one=True)
        if saved["request_status"] == "Rejected":      # the trigger stored it as Rejected (unverified NGO / expired / over-allocated)
            flash("Request rejected: the NGO must be verified, the food must still be available and the quantity cannot be more than the stock.", "danger")
        else:
            flash("Request placed. Waiting for admin approval.", "success")
    except mysql.connector.Error as e:
        flash(db_message(e), "danger")
    return redirect(url_for("listings.browse"))

@listings_bp.route("/ngo/requests")
@login_required("NGO")
def my_requests():
    rows = query("""SELECT r.request_id, f.food_name, d.donor_name, r.quantity_kg, r.requested_on,
                           r.request_status, dl.delivery_status
                    FROM Collection_Request r
                    JOIN Food_Listing f ON f.listing_id = r.listing_id
                    JOIN Donor d ON d.donor_id = f.donor_id
                    LEFT JOIN Delivery dl ON dl.request_id = r.request_id
                    WHERE r.ngo_id = %s ORDER BY r.requested_on DESC""", (session["pid"],))
    return render_template("my_requests.html", rows=rows)


@listings_bp.route("/ngo/requests/<int:request_id>/cancel", methods=["POST"])
@login_required("NGO")
def cancel_request(request_id):
    execute("""UPDATE Collection_Request SET request_status='Cancelled'
               WHERE request_id=%s AND ngo_id=%s AND request_status='Pending'""", (request_id, session["pid"]))
    flash("If the request was still pending it has been cancelled.", "success")
    return redirect(url_for("listings.my_requests"))


# ---------------- ADMIN ----------------
@listings_bp.route("/admin/requests")
@login_required("Admin")
def admin_requests():
    expire_listings()
    rows = query("SELECT * FROM v_pending_requests ORDER BY requested_on")
    return render_template("admin_requests.html", rows=rows)


@listings_bp.route("/admin/requests/<int:request_id>/<action>", methods=["POST"])
@login_required("Admin")
def decide_request(request_id, action):
    try:
        if action == "approve":
            execute("UPDATE Collection_Request SET request_status='Approved' WHERE request_id=%s AND request_status='Pending'", (request_id,))
            now = query("SELECT request_status FROM Collection_Request WHERE request_id=%s", (request_id,), one=True)
            if now and now["request_status"] == "Approved":      # the triggers checked everything and deducted the stock
                flash("Request approved. Stock was deducted automatically.", "success")
            else:
                flash("The request could not be approved (food expired, not enough stock, NGO daily capacity reached, or it was no longer pending), so it is now " +
                      (now["request_status"] if now else "missing") + ".", "danger")
        elif action == "reject":
            execute("UPDATE Collection_Request SET request_status='Rejected' WHERE request_id=%s AND request_status='Pending'", (request_id,))
            flash("Request rejected.", "success")
    except mysql.connector.Error as e:
        flash(db_message(e), "danger")
    return redirect(url_for("listings.admin_requests"))
